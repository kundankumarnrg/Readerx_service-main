from fastapi import FastAPI
from app.api.routers import extract  # Ensure correct import

app = FastAPI()

# Include the router
app.include_router(extract.router)


# uvicorn app.main:app --reload