from fastapi import APIRouter, UploadFile, File, HTTPException
import shutil
import os
from app.services.ocr_service import extract_text_from_file

router = APIRouter()

UPLOAD_DIR = "temp_uploads"  # Temporary folder for uploads
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.post("/extract-text/")
async def extract_text(file: UploadFile = File(...)):
    """Extract text from uploaded PDF or image."""
    try:
        # Save the uploaded file temporarily
        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # Extract text
        text = extract_text_from_file(file_path)

        # Remove file after processing
        os.remove(file_path)

        return {"filename": file.filename, "extracted_text": text}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
===========================================================================================================
#code for me
from fastapi import APIRouter, UploadFile, File, HTTPException
import shutil
import os
from app.services.ocr_service import extract_text_from_file
import json
import re 

router = APIRouter()

UPLOAD_DIR = "temp_uploads"  # Temporary folder for uploads
STORE_JSON_RAW_DATA_DIR = "raw_data"        # Raw json file folder 
RESULTED_JSON_DATA_DIR = "resulted_json_data"   # Cleaned json file folder 

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(STORE_JSON_RAW_DATA_DIR,exist_ok=True)
os.makedirs(RESULTED_JSON_DATA_DIR,exist_ok=True)

@router.post("/extract-text/")
async def extract_text(file: UploadFile = File(...)):
    """Extract text from uploaded PDF or image."""
    try:
        # Save the uploaded file temporarily
        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        # Extract text
        text = extract_text_from_file(file_path)
        
        # Remove file after processing
        os.remove(file_path)

        #Save the extracted data into json raw file
        json_raw_data_path = os.path.join(STORE_JSON_RAW_DATA_DIR,file.filename)
        print(json_raw_data_path)
        with open(json_raw_data_path, "w") as json_file:
            json.dump(text,json_file)


        #Extracting values raw json to Pretty json
        json_raw_data_path = "D:/Work sapce/readerx_service-main/raw_data/image.PNG"
        with open(json_raw_data_path,"r") as raw_json_file:
            raw_json_data = json.load(raw_json_file)


        # Extracting values using regex patterns
        extracted_data = {
            "service_no": re.search(r"(\d{10})", raw_json_data).group(1) if re.search(r"(\d{10})", raw_json_data) else None,
            "bill_amount": re.search(r"(?<=Bill Amount:)\s*(\d+)", raw_json_data).group(1) if re.search(r"(?<=Bill Amount:)\s*(\d+)", raw_json_data) else None,
            "receipt_no": re.search(r"(PGN\w+)", raw_json_data).group(1) if re.search(r"(PGN\w+)", raw_json_data) else None,
            "amount_debited": re.search(r"(\d+\.\d+)", raw_json_data).group(1) if re.search(r"(\d+\.\d+)", raw_json_data) else None,
            
        }

        #Remove None Values
        cleanded_data = {key: val for key, val in extracted_data.items() if val is not None}

        #Save the clean data 
        resulted_json_data_path = os.path.join(RESULTED_JSON_DATA_DIR,file.filename)
        with open(resulted_json_data_path, 'w') as resulted_json_file:
            json.dump(cleanded_data,resulted_json_file)
            
        






        # #convert extracted text into json
        # raw_json_data = json.dumps(text,indent=4)
        # print(raw_json_data)
        # text_data = raw_json_data["invoice"]["extracted_text"]

        # Extracting values using regex patterns
        # extracted_data = {
        #     "organization": "Tamilnadu Generation and Distribution Corporation Limited",
        #     "service_no": re.search(r"(\d{10})", text_data).group(1) if re.search(r"(\d{10})", text_data) else None,
        #     "bill_amount": re.search(r"(?<=Bill Amount:)\s*(\d+)", text_data),
        #     "receipt_no": re.search(r"(PGN\w+)", text_data).group(1) if re.search(r"(PGN\w+)", text_data) else None,
        #     "amount_debited": re.search(r"(\d+\.\d+)", text_data).group(1) if re.search(r"(\d+\.\d+)", text_data) else None,
        #     "customer_name": re.search(r"(?<=Name:)\s*([A-Z\s]+)", text_data).group(1).strip() if re.search(r"(?<=Name:)\s*([A-Z\s]+)", text_data) else None,
        #     "month_year": re.search(r"(\d{2}/\d{4})", text_data).group(1) if re.search(r"(\d{2}/\d{4})", text_data) else None,
        #     "receipt_date": re.search(r"(\w+, \d+ \w+ \d{4})", text_data).group(1) if re.search(r"(\w+, \d+ \w+ \d{4})", text_data) else None,
        #     "transaction_no": re.search(r"(\d{12})", text_data).group(1) if re.search(r"(\d{12})", text_data) else None,
        #     "bank": "HDFC NET BANKING",
        #     "card_type": "NET BANKING"
        # }
        # # Remove None values
        # cleaned_data = {k: v for k, v in extracted_data.items() if v is not None}

        # # Pretty-print JSON output
        # pretty_json_data = json.dumps(cleaned_data, indent=4)

        # #save Json data to a file
        # json_file_path = os.path.join(OUTPUT_DIR, f"{file.filename}.json")
        # with open(json_file_path, "w", encoding="utf=8") as json_file:
        #     json.dump(pretty_json_data, json_file, indent=4)

        # invoice_data = {
        #     "invoice": {
        #         "extracted_text" : text
        #     }
        # }

        #save Json data to a file
        # json_file_path = os.path.join(OUTPUT_DIR, f"{file.filename}.json")
        # with open(json_file_path, "w", encoding="utf=8") as json_file:
        #     json.dump(invoice_data, json_file, indent=4)

        
        return {"filename": file.filename, "extracted_text": cleanded_data}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
       





















# @router.post("/resulted-data/")
# async def extract_text(text):
#     """Convert extracted string into structured JSON"""
#     try:
#         # Extracting values using regex patterns
#         extracted_data = {
#             "organization": "Tamilnadu Generation and Distribution Corporation Limited",
#             "service_no": re.search(r"(\d{10})", text).group(1) if re.search(r"(\d{10})", text) else None,
#             "bill_amount": re.search(r"(?<=Bill Amount:)\s*(\d+)", text).group(1) if re.search(r"(?<=Bill Amount:)\s*(\d+)", text) else None,
#             # "receipt_no": re.search(r"(PGN\w+)", EXTRACTED_TEXT).group(1) if re.search(r"(PGN\w+)", EXTRACTED_TEXT) else None,
#             # "amount_debited": re.search(r"(\d+\.\d+)", EXTRACTED_TEXT).group(1) if re.search(r"(\d+\.\d+)", EXTRACTED_TEXT) else None,
#             # "customer_name": re.search(r"(?<=Name:)\s*([A-Z\s]+)", EXTRACTED_TEXT).group(1).strip() if re.search(r"(?<=Name:)\s*([A-Z\s]+)", EXTRACTED_TEXT) else None,
#             # "month_year": re.search(r"(\d{2}/\d{4})", EXTRACTED_TEXT).group(1) if re.search(r"(\d{2}/\d{4})", EXTRACTED_TEXT) else None,
#             # "receipt_date": re.search(r"(\w+, \d+ \w+ \d{4})", EXTRACTED_TEXT).group(1) if re.search(r"(\w+, \d+ \w+ \d{4})", EXTRACTED_TEXT) else None,
#             # "transaction_no": re.search(r"(\d{12})", EXTRACTED_TEXT).group(1) if re.search(r"(\d{12})", EXTRACTED_TEXT) else None,
#             # "bank": "HDFC NET BANKING",
#             # "card_type": "NET BANKING"
#         }

#         # Remove None values
#         cleaned_data = {k: v for k, v in extracted_data.items() if v is not None}

#         return {"extracted_data": cleaned_data}

#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))


# # @router.post("/show-json-data/")
# # async def show_json_data(file:show_json_data = File(...)):
# #      return {"filename": file.filename}
    

# # @router.post("/uploadfile/")
# # async def upload_file(file: UploadFile = File(...)):
# #     print("test-1")
# #     with open(f'temp_uploads/{file.filename}', 'wb') as f:
# #         shutil.copyfileobj(file.file, f)
# #     print("test-2")
# #     # Read the file content after saving (example)
# #     with open(f'temp_uploads/{file.filename}', 'r') as f:
# #         file_content = f.read()
# #     print("test-3")
# #     return {"filename": file.filename, "content": file_content[:100]}  # first 100 chars


# # @router.get("/test/")
# # async def test_file():
    

# #     return {"filename":'test'}  # first 100 chars

