import os
import filetype
import pytesseract
from pdf2image import convert_from_path
from PIL import Image, UnidentifiedImageError

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
POPPLER_PATH = r"C:\Program Files\poppler-24.08.0\Library\bin"

def extract_text_from_file(file_path: str) -> str:
    """Extract text from an image or PDF file."""
    
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    # Detect file type
    kind = filetype.guess(file_path)
    if not kind:
        raise ValueError("Unsupported or unknown file type")

    extracted_text = ""

    try:
        if kind.mime == "application/pdf":
            # Convert PDF to images
            pdf_images = convert_from_path(file_path, dpi=300, poppler_path=POPPLER_PATH)
            extracted_text = "\n".join(pytesseract.image_to_string(image) for image in pdf_images)

        elif kind.mime.startswith("image/"):
            # Process a single image
            try:
                img = Image.open(file_path)
                extracted_text = pytesseract.image_to_string(img)
            except UnidentifiedImageError:
                raise ValueError(f"Invalid or corrupt image file: {file_path}")

        else:
            raise ValueError(f"Unsupported file format: {kind.mime}")

    except Exception as e:
        raise RuntimeError(f"Error processing file {file_path}: {e}")

    return extracted_text.strip()
