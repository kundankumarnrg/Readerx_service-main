import os

# Tesseract OCR Path (Modify if needed)
TESSERACT_CMD = os.getenv("TESSERACT_CMD", "tesseract")
